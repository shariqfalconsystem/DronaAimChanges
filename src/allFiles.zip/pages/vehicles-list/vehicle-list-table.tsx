import React, { useCallback, useEffect, useState, useRef } from 'react';
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
  Typography,
  TextField,
  IconButton,
  Menu,
  MenuItem,
  Checkbox,
  FormControlLabel,
  Button,
} from '@mui/material';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { TbTriangleFilled, TbTriangleInvertedFilled } from 'react-icons/tb';
import { MdViewColumn } from 'react-icons/md';
import debounce from 'lodash/debounce';

const VehicleListTable = ({
  vehiclesInformation,
  onEditVehicle,
  onLinkVehicle,
  onDeleteVehicle,
  onPageChange,
  onSearch,
  onSort,
  currentPage,
  setCurrentPage,
  filterCriteria,
  searchQueries,
  setSearchQueries,
  setSortColumn,
  sortColumn,
  sortDirection,
  setSortDirection,
  isUnInsuredFleet,
  role,
}) => {
  const navigate = useNavigate();
  const [localSearchQueries, setLocalSearchQueries] = useState({});
  const containerRef = useRef(null);
  const tableRef = useRef(null);
  const [applyBackdropFilter, setApplyBackdropFilter] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [vehicleToDelete, setVehicleToDelete] = useState(null);
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Column visibility state
  const [anchorEl, setAnchorEl] = useState(null);
  const [visibleColumns, setVisibleColumns] = useState({
    vehicleId: true,
    status: true,
    meanScore: true,
    vin: true,
    tagLicencePlateNumber: true,
    make: true,
    model: true,
    year: true,
    deviceId: true,
    partnerName: true,
    customVehicleId: true,
    imeiByDevice: true,
    actions: true,
  });

  const columns = [
    { label: 'Vehicle ID', key: 'vehicleId', hideable: false },
    { label: 'Vehicle Status', key: 'status', hideable: true },
    { label: 'Vehicle Score', key: 'meanScore', hideable: true },
    { label: 'VIN', key: 'vin', hideable: true },
    { label: 'License plate', key: 'tagLicencePlateNumber', hideable: true },
    { label: 'Make', key: 'make', hideable: true },
    { label: 'Model', key: 'model', hideable: true },
    { label: 'Year', key: 'year', hideable: true },
    { label: 'Device ID', key: 'deviceId', hideable: true },
    { label: 'Device Provider', key: 'partnerName', hideable: true },
    { label: 'Custom Vehicle ID', key: 'customVehicleId', hideable: true },
    { label: 'IMEI Number', key: 'imeiByDevice', hideable: true },
    { label: 'Actions', key: 'actions', hideable: false },
  ];

  const handleOpenColumnMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseColumnMenu = () => {
    setAnchorEl(null);
  };

  const handleToggleColumn = (columnKey) => {
    setVisibleColumns((prev) => ({
      ...prev,
      [columnKey]: !prev[columnKey],
    }));
  };

  useEffect(() => {
    setLocalSearchQueries(searchQueries);
  }, [searchQueries]);

  const handleSort = (column, direction) => {
    setSortColumn(column);
    setSortDirection(direction);
    setCurrentPage(1);
    setSearchParams({ page: '1' });
    onSort(column, direction);
  };

  const debouncedSearch = useCallback(
    debounce((queries) => {
      onSearch(queries);
      setCurrentPage(1);
      setSearchParams({ page: '1' });
      setSearchQueries(queries);
    }, 1000),
    [onSearch, setSearchQueries]
  );

  useEffect(() => {
    return () => {
      debouncedSearch.cancel();
    };
  }, [debouncedSearch]);

  const handleColumnSearch = (column, value) => {
    const newQueries = { ...localSearchQueries, [column]: value };
    if (value === '') {
      delete newQueries[column];
    }
    setLocalSearchQueries(newQueries);
    debouncedSearch(newQueries);
  };

  const handleScroll = (event) => {
    const target = event.target;
    setApplyBackdropFilter(target.scrollLeft > 0);
  };

  const handleLinkClick = (e, vehicle) => {
    e.stopPropagation();
    e.preventDefault();
    onLinkVehicle(vehicle);
  };

  const handleEditClick = (e, vehicle) => {
    e.stopPropagation();
    e.preventDefault();
    onEditVehicle(vehicle);
  };

  const handleDeleteClick = (e, vehicle) => {
    e.stopPropagation();
    e.preventDefault();
    setVehicleToDelete(vehicle);
    setDeleteConfirmOpen(true);
  };

  const handleConfirmDelete = () => {
    if (vehicleToDelete) {
      onDeleteVehicle(vehicleToDelete.vehicleId);
    }
    setDeleteConfirmOpen(false);
    setVehicleToDelete(null);
  };

  const handleCancelDelete = () => {
    setDeleteConfirmOpen(false);
    setVehicleToDelete(null);
  };

  const totalPages = Math.ceil(vehiclesInformation?.pageDetails?.totalRecords / 10) || 1;

  // Filter visible columns
  const visibleColumnsList = columns.filter((col) => visibleColumns[col.key]);

  return (
    <Box sx={{ maxWidth: '81vw', overflowX: 'auto' }}>
      {/* Column Filter Button */}
      <Box sx={{ mb: 2, display: 'flex', justifyContent: 'flex-end' }}>
        <Button
          variant="outlined"
          startIcon={<MdViewColumn />}
          onClick={handleOpenColumnMenu}
          sx={{
            textTransform: 'none',
            borderColor: '#5B7C9D',
            color: '#5B7C9D',
            '&:hover': {
              borderColor: '#4a5c72',
              backgroundColor: 'rgba(91, 124, 157, 0.04)',
            },
          }}
        >
          Columns
        </Button>
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleCloseColumnMenu}
          PaperProps={{
            sx: {
              maxHeight: 400,
              width: 250,
            },
          }}
        >
          {columns.map((column) => (
            <MenuItem
              key={column.key}
              disabled={!column.hideable}
              onClick={() => column.hideable && handleToggleColumn(column.key)}
            >
              <FormControlLabel
                control={
                  <Checkbox
                    checked={visibleColumns[column.key]}
                    disabled={!column.hideable}
                    size="small"
                  />
                }
                label={column.label}
                sx={{ width: '100%', m: 0 }}
              />
            </MenuItem>
          ))}
        </Menu>
      </Box>

      <TableContainer
        ref={containerRef}
        component={Paper}
        onScroll={handleScroll}
        sx={{
          overflowX: 'auto',
          '&::-webkit-scrollbar': {
            width: '8px',
            height: '14px',
            cursor: 'pointer',
          },
          '&::-webkit-scrollbar-track': {
            backgroundColor: '#f1f1f1',
          },
          '&::-webkit-scrollbar-thumb': {
            backgroundColor: '#5B7C9D',
            borderRadius: '5px',
          },
          '&::-webkit-scrollbar-thumb:hover': {
            backgroundColor: '#4a5c72',
          },
        }}
      >
        <Table ref={tableRef} sx={{ width: '120%' }}>
          <TableHead>
            <TableRow>
              {visibleColumnsList.map(({ label, key }, index) => {
                const isFirstColumn = index === 0;
                const isLastColumn = index === visibleColumnsList.length - 1;
                
                return (
                  <th
                    key={key}
                    style={{
                      position: isFirstColumn || isLastColumn ? 'sticky' : 'static',
                      left: isFirstColumn ? 0 : 'auto',
                      right: isLastColumn ? 0 : 'auto',
                      zIndex: isFirstColumn || isLastColumn ? 2 : 'auto',
                      backdropFilter: 'blur(50px)',
                      backgroundColor: '#f5f5f5',
                      padding: '16px',
                      borderBottom: '1px solid #e0e0e0',
                    }}
                  >
                    <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                      <Typography
                        sx={{
                          whiteSpace: 'nowrap',
                          color: '#000!important',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '0.75rem',
                          fontWeight: 600,
                        }}
                        component="span"
                      >
                        {label}
                        <Box sx={{ display: 'flex', flexDirection: 'column', ml: 1 }}>
                          {key !== 'actions' && (
                            <>
                              <TbTriangleFilled
                                size={8}
                                color={sortColumn === key && sortDirection === 'ASC' ? '#000' : 'rgba(0,0,0,0.5)'}
                                onClick={() => handleSort(key, 'ASC')}
                                style={{ cursor: 'pointer' }}
                              />
                              <TbTriangleInvertedFilled
                                size={8}
                                color={sortColumn === key && sortDirection === 'DESC' ? '#000' : 'rgba(0,0,0,0.5)'}
                                onClick={() => handleSort(key, 'DESC')}
                                style={{ cursor: 'pointer' }}
                              />
                            </>
                          )}
                        </Box>
                      </Typography>
                      {key !== 'actions' && (
                        <TextField
                          size="small"
                          variant="outlined"
                          value={localSearchQueries[key] || ''}
                          onChange={(e) => handleColumnSearch(key, e.target.value)}
                          sx={{
                            mt: 1,
                            '& .MuiOutlinedInput-root': {
                              backgroundColor: 'white',
                              width: '100%',
                              height: '30px',
                            },
                          }}
                        />
                      )}
                    </Box>
                  </th>
                );
              })}
            </TableRow>
          </TableHead>
          <TableBody>
            {vehiclesInformation?.vehicles && vehiclesInformation?.vehicles.length > 0 ? (
              vehiclesInformation?.vehicles.map((vehicle) => (
                <TableRow
                  key={vehicle?.vehicleId}
                  onClick={() => {
                    navigate(`/vehicles-details/${vehicle?.vin}/`, {
                      state: vehicle,
                    });
                  }}
                  sx={{
                    '&:hover': {
                      backgroundColor: '#f5f5f5',
                      cursor: 'pointer',
                    },
                  }}
                >
                  {visibleColumnsList.map((column, index) => {
                    const isFirstColumn = index === 0;
                    const isLastColumn = index === visibleColumnsList.length - 1;
                    
                    return (
                      <td
                        key={column.key}
                        style={{
                          position: isFirstColumn || isLastColumn ? 'sticky' : 'static',
                          left: isFirstColumn ? 0 : 'auto',
                          right: isLastColumn ? 0 : 'auto',
                          zIndex: isFirstColumn || isLastColumn ? 1 : 'auto',
                          backdropFilter: applyBackdropFilter && (isFirstColumn || isLastColumn) ? 'blur(50px)' : 'none',
                          background: applyBackdropFilter && (isFirstColumn || isLastColumn) ? '#f5f5f5' : 'inherit',
                          boxShadow: isFirstColumn || isLastColumn ? '2px 0 5px rgba(0,0,0,0.1)' : 'none',
                          padding: '16px',
                          borderBottom: '1px solid #e0e0e0',
                        }}
                      >
                        {column.key === 'vehicleId' && (vehicle?.vehicleId || 'NA')}
                        {column.key === 'status' && <span style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: vehicle?.vehicleStatus === 'Active' ? '#e8f5e9' : '#ffebee' }}>{vehicle?.vehicleStatus || 'NA'}</span>}
                        {column.key === 'meanScore' && <Box sx={{ padding: '4px 12px', borderRadius: '4px', backgroundColor: '#e3f2fd', fontWeight: 600 }}>{vehicle?.meanScore?.toFixed(1) || 0}</Box>}
                        {column.key === 'vin' && (vehicle?.vin || 'NA')}
                        {column.key === 'tagLicencePlateNumber' && (vehicle?.tagLicencePlateNumber || 'NA')}
                        {column.key === 'make' && (vehicle?.make || 'NA')}
                        {column.key === 'model' && (vehicle?.model || 'NA')}
                        {column.key === 'year' && (vehicle?.year || 'NA')}
                        {column.key === 'deviceId' && (vehicle?.lookup_devices?.[0]?.deviceId || 'NA')}
                        {column.key === 'partnerName' && (vehicle?.lookup_devices?.[0]?.deviceProvider || 'NA')}
                        {column.key === 'customVehicleId' && (vehicle?.customVehicleId || 'NA')}
                        {column.key === 'imeiByDevice' && (vehicle?.lookup_devices?.[0]?.imei || 'NA')}
                        {column.key === 'actions' && (
                          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1 }}>
                            <IconButton size="small" onClick={(e) => handleLinkClick(e, vehicle)}>
                              <span style={{ fontSize: '1.2rem' }}>🔗</span>
                            </IconButton>
                            <IconButton size="small" onClick={(e) => handleEditClick(e, vehicle)}>
                              <span style={{ fontSize: '1.2rem' }}>✏️</span>
                            </IconButton>
                            {isUnInsuredFleet && role === 'fleetManagerSuperUser' && (
                              <IconButton size="small" onClick={(e) => handleDeleteClick(e, vehicle)}>
                                <span style={{ fontSize: '1.2rem' }}>🗑️</span>
                              </IconButton>
                            )}
                          </Box>
                        )}
                      </td>
                    );
                  })}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <td colSpan={visibleColumnsList.length} style={{ textAlign: 'center', padding: '20px' }}>
                  <Typography variant="body1">No Vehicles Found</Typography>
                </td>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      
      {/* Pagination component would go here */}
      <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
        <Typography variant="body2">
          Page {currentPage} of {totalPages} | Total Records: {vehiclesInformation?.pageDetails?.totalRecords || 0}
        </Typography>
      </Box>
    </Box>
  );
};

export default VehicleListTable;