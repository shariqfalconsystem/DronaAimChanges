// models/UserData.ts

interface UserData {}

export default UserData;
